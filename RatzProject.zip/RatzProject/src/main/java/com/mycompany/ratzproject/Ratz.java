/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.ratzproject;

import java.util.Scanner;
import java.util.concurrent.ThreadLocalRandom;

/**
 *
 * @author Sara
 */
public class Ratz {

     public static void main(String[] args) {
        Scanner leitor = new Scanner (System.in);
        Integer inteira = 0;
        
        do{
        System.out.println("Digite um número correspondente"
                    + "a operação desejada: \n"
                    + "1: Compra de filhotes \n"
                    + "2: Quantidade de ratos por medida \n"
                    + "3: Curiosidades sobre ratos \n"
                    + "0: Sair \n"
            );
        
        Integer escolha = leitor.nextInt();
        inteira = escolha;
        
        
       String nome = "Compra de filhotes";
            String nome2 = "Quantidade de ratos por medida";
            String nome3 = "Curiosidades sobre ratos";
            String nome4 = "Sair";
        
        
        switch(escolha){
            
                 case 1:
                
                     Scanner raca = new Scanner (System.in);
                     Scanner quantidade = new Scanner (System.in);
                     
                    String preto = "Preto";
                    String agouti = "Agouti";
                    String himalaya = "Himalaya";
                    String faw = "Faw";
                    String silverFawn = "Silver Fawn";
                    String marcacaoComum = "Marcações comuns";
                    String mink = "Mink";
                    String cinnamon = "Cinnamon";
                    String havana = "Havana";
                    String oddEyes = "Odd Eyes";
                    String silverManes = "Silver Manes";
                    String bew = "Bew";
                    String americanBlue = "American Blue";
                    String powderBlue = "Powder Blue";
                    String russianSilver = "Russian Silver";
                    String marcacaoExotica = "Marcações exóticas";
                    
                    
                    Integer valorRato = 0;
                    
                    System.out.println("Informe a raça do rato");
                    String racaDigitada = raca.nextLine();
                    
                    System.out.println(String.format("Digite a quantidade de ratos: "));
                    Integer quantidadeDigitada = quantidade.nextInt();
                    
                    if(racaDigitada.equalsIgnoreCase("preto") || racaDigitada.equalsIgnoreCase("agouti")
                            || racaDigitada.equalsIgnoreCase("himalaya") || racaDigitada.equalsIgnoreCase("faw")
                            || racaDigitada.equalsIgnoreCase("silverFawn") || racaDigitada.equalsIgnoreCase("marcacaoComum")){
                        valorRato = 120 * quantidadeDigitada;
                        System.out.println("O valor fica " + valorRato + "\n");
                    }else if(racaDigitada.equalsIgnoreCase("mink") || racaDigitada.equalsIgnoreCase("cinnamon")
                            || racaDigitada.equalsIgnoreCase("havana") || racaDigitada.equalsIgnoreCase("oddEyes")){
                        valorRato = 120 * quantidadeDigitada;
                        System.out.println("O valor fica " + valorRato + "\n");
                    }else if(racaDigitada.equalsIgnoreCase("silverManes") || racaDigitada.equalsIgnoreCase("bew")
                            || racaDigitada.equalsIgnoreCase("americanBlue") || racaDigitada.equalsIgnoreCase("powderBlue")
                            ||  racaDigitada.equalsIgnoreCase("russianSilver") ||  racaDigitada.equalsIgnoreCase("marcacaoExotica")){
                        valorRato = 135 * quantidadeDigitada;
                        System.out.println("O valor fica " + valorRato + "\n");
                    }else if(racaDigitada.equalsIgnoreCase("silverManes") || racaDigitada.equalsIgnoreCase("bew")
                            || racaDigitada.equalsIgnoreCase("americanBlue") || racaDigitada.equalsIgnoreCase("powderBlue")
                            ||  racaDigitada.equalsIgnoreCase("russianSilver") ||  racaDigitada.equalsIgnoreCase("marcacaoExotica")){
                        valorRato = 135 * quantidadeDigitada;
                        System.out.println("O valor fica " + valorRato + "\n");
                    }
                 
                    break;
            
                case 2:
                   
                    System.out.println(String.format("%s \n", nome2));

                    System.out.println("Me informe as medidas da sua gaiola Ipanema: \n"
                            + "Altura: \n"
                            + "Largura: \n"
                            + "Comprimento: \n"
                    );   
                    Double altura = leitor.nextDouble();
                    Double largura = leitor.nextDouble();
                    Double comprimento = leitor.nextDouble();

                    if (altura <= 40 && largura <= 45 && comprimento <= 48) {
                        System.out.println("Sua gaiola não comporta nenhum rato.");
                    } else if (altura == 85 && largura == 60 && comprimento == 40) {
                        System.out.println("Sua gaiola comporta 2 ratos,"
                                + "(5 Machos ou 7 femêas.)");
                    } else if (altura == 98 && largura == 50 && comprimento == 120) {
                        System.out.println("Sua gaiola comporta 2 ratos,"
                                + "(10 Machos ou 13 femêas.)");
                    } else if (altura == 98 && largura == 50 && comprimento == 120) {
                        System.out.println("Sua gaiola comporta 2 ratos,"
                                + "(10 Machos ou 13 femêas por andar.)");
                    } else if (altura == 90 && largura == 60 && comprimento == 60) {
                        System.out.println("Sua gaiola comporta 2 ratos,"
                                + "(5 Machos ou 7 femêas.)");
                    } else if (altura == 90 && largura == 60 && comprimento == 120) {
                        System.out.println("Sua gaiola comporta 2 ratos,"
                                + "(11 Machos (5 por andar) ou 15 femêas"
                                + "(7 por andar).)");
                    } else {
                        System.out.println("Apenas calculamos medidas das gaiolas"
                                + "Ipanema, caso precise de mais informações"
                                + "entre neste link: https://www.lojagaiolasipanema.com.br/roedores/twister \n");

                    }
                    
                    System.out.println("Digite um número do menu: \n");
                   
                    break;
                        
             case 3:
                    
                    System.out.println(String.format("%s \n", nome3)); 
                    
                    System.out.println("Insira um número de 1 a 5: \n");   
                   
                    Integer numDig = leitor.nextInt();

                    if (numDig < 1 || numDig > 5) {
                        System.out.println("Digite um número apenas entre 1 e 5.");
                         break;
                    } else {

                            Integer numeroSorteado = ThreadLocalRandom.current().nextInt(1, 5);

                            if (numeroSorteado == 1) {
                                System.out.println("Um estudo da Universidade de "
                                        + "Chicago testou se ratos se importam uns com os outros. Nele, "
                                        + "os pesquisadores separaram os ratos em duplas e os deixaram juntos por tempo "
                                        + "o suficiente para que criassem um laço. Depois, prenderam um dos ratos em um caixa"
                                        + " de acrílico que só podia ser aberta por fora, para ver se o outro roedor tentaria "
                                        + "ajudar o amigo.\n"
                                        + "\n"
                                        + "Para dificultar ainda mais a decisão do ratinho que estava fora, "
                                        + "os pesquisadores colocaram uma segunda caixa semelhante com o petisco "
                                        + "favorito dos ratos dentro. Mesmo assim, quando ele teve que decidir entre "
                                        + "ajudar o amigo ou abrir a caixa de petiscos, primeiro ele salvou o amigo e depois "
                                        + "os dois comeram os petiscos juntos. \n");
                            }else if(numeroSorteado == 2){
                                System.out.println("Ratos são extremamente adaptáveis e isso foi crucial para que eles se espalhassem "
                                        + "pelo mundo inteiro. Eles podem, por exemplo, ficar mais tempo sem beber água do que camelos e"
                                        + " cair de um prédio de 5 andares sem se machucarem. Esses roedores também são capazes de "
                                        + "suportar altas doses de radiação e de nadar por quase 1 km. \n");
                            }else if(numeroSorteado == 3){
                                System.out.println("Em 2014, pesquisadores revisaram nos registros geológicos quais espécies prosperaram, "
                                        + "mesmo durante extinções em massa. Com base no passado e nas habilidades dos animais que existem "
                                        + "atualmente, os pesquisadores apontaram os ratos como vencedores da corrida contra a extinção, "
                                        + "já que eles têm um histórico muito positivo de sobrevivência e resistência em diversos tipos "
                                        + "de ambientes e a programas de erradicação. \n");
                            }else if(numeroSorteado == 4){
                                System.out.println("Um estudo de 2018 capturou 150 roedores por diversas zonas das cidades de Vancouver,"
                                        + " Nova York, Nova Orleans e Salvador. Os pesquisadores analisaram o material genético dos roedores"
                                        + " de cada cidade e descobriram que eles se dividiam em grupos pela área. Havia ratos de “uptown” e "
                                        + "“downtown” em Nova York, e o mesmo acontecia nas outras cidades.\n" 
                                        + "Os pesquisadores concluíram que os grupos foram separados por rodovias, canais ou vales que cortavam "
                                        + "as cidades, e que ratos de áreas menores preferiam ficar entre os seus do que interagir com roedores de outras áreas. \n");
                            }else{
                                System.out.println("Em Moçambique, existe uma espécie de rato gigante treinada para detectar o cheiro de explosivos. Após passar "
                                        + "pelo treinamento, esses ratos saem para o campo com especialistas em remoção de minas terrestres e arranham o chão para "
                                        + "indicar onde encontraram uma das bombas. Como os roedores são leves demais para acionar o mecanismo da mina, eles não correm "
                                        + "perigo algum, mas ajudam a salvar muitas vidas. \n");
                            }
                                   System.out.println("Digite um número do menu: \n");
                                 

                                   break;
                        } 
            
            case 0: 
                System.out.println(String.format("Até mais! Squik Skquik <3")); 
                break;
            default:
            System.out.println("Opção inválida, tente novamente \n");
                
            break;
        }
        
          }while(inteira != 0);
}
}