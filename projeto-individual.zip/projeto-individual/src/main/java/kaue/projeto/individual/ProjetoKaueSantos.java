/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package kaue.projeto.individual;

import java.util.Scanner;
import java.util.concurrent.ThreadLocalRandom;

/**
 *
 * @author rails
 */
public class ProjetoKaueSantos {
    public static void main(String[] args) {
        Scanner leitor = new Scanner(System.in);
        
        Boolean acesso = true;
        
            Double saldo = 0.0;
            
        while (acesso) {
            System.out.println("\n");
            System.out.println("Olá, bem-vindo(a) ao KaPointsBank");
            System.out.println("-----------------------\n");
            System.out.println("O que deseja fazer:");
            System.out.println("1 - Depositar KPoints");
            System.out.println("2 - Gastar KPoints");
            System.out.println("3 - Ver meu rendimento de KPoints");
            System.out.println("4 - Jogo de aposta");
            System.out.println("0 - Sair");
            System.out.println("-----------------------");
            Integer numeroEscolhido = leitor.nextInt();
            
            
            switch (numeroEscolhido){
            case 1:
                
                System.out.println("\n");
                System.out.println("Digite o valor do depósito:");
                Double depositoDigitado = leitor.nextDouble();
                
                
                if (depositoDigitado > 0) {
                    
                    saldo += depositoDigitado; 
           
                    //System.out.println("Depósito realizado - Saldo atual: R$:" 
                    //+ saldo);
                    
                    System.out.println(String.format("Depósito realizado - "
                            + "Coins atuais: %.2f KPoints", saldo));
                    
                } else {
                    System.out.println("Valor inválido");
                }
                
                break;
                
            case 2:
                
                System.out.println("\n");
                System.out.println("Digite o valor do saque:");
                
                Double saqueDigitado = leitor.nextDouble();
                    
                
                if (saqueDigitado > 0 && saqueDigitado < saldo) {
                    
                    saldo = saldo - saqueDigitado;
                    
                    System.out.println(String.format("Saque realizado, dia de compras!!!"
                            + " - Coins atuais: %.2f KPoints", saldo));
                    
                } else {
                    System.out.println("Valor inválido - deposite KPoints em sua"
                            + " conta ou digite um número maior que 0");
                }
                
                break;
                
            case 3:
                
                if (saldo > 0) {
                    
                    Double saldoSimulacao = saldo;
                    
                    System.out.println("\n");
                    System.out.println(String.format("Saldo atual: R$:%.2f", saldo));
                    System.out.println("-----------------------");
                    for (int i = 1; i <= 12; i++) {
                        System.out.println(String.format("Mês %d | Saldo: R$%.2f", i, saldoSimulacao));
                        saldoSimulacao = saldoSimulacao + (saldoSimulacao*0.1);
                        
                    }
                    System.out.println("-----------------------");
                } else {
                    
                    System.out.println("\n");
                    System.out.println("Saldo Zerado, opção inválida.");
                }
                
                break;
                
                
                
            case 4:
                
                System.out.println("\n");
                System.out.println("Bem-vindo(a) ao mini-game para ganhar mais KPoints");
                System.out.println("--------------------------------------------\n");
                System.out.println("Digite um número de 0 a 10");
                
                Integer numeroDigitado = leitor.nextInt();
                Integer numeroRandom = ThreadLocalRandom.current().nextInt(0, 10);
                
                Integer cont = 0;
                
                if (numeroDigitado >= 0 && numeroDigitado <= 10) {
                    

                System.out.println(String.format("Número sorteado %d", numeroRandom));
                System.out.println("-----------------------");
                
                } else{
                    
                        System.out.println("Digite um número válido");
                }
                
        while (numeroDigitado != numeroRandom) {
            
            System.out.println("\n");
            System.out.println("Digite um número de 0 a 10");
            
            numeroDigitado = leitor.nextInt();
            
            
            numeroRandom = ThreadLocalRandom.current().nextInt(0, 11);
            
            if (numeroDigitado >= 0 && numeroDigitado <= 10) {
                
            
            //System.out.println("Numero sorteado: " + numeroRandom);
            System.out.println(String.format("Numero sorteado %d", numeroRandom));
            System.out.println("--------------------------------------------");
            cont++;
            
            } else {
                System.out.println("Digite um número válido");
            }

        }
        
        
        if (cont <= 3) {
            
            saldo += 5;
            
            System.out.println("Você é MUITO sortudo - VocÊ ganhou 5 KPoints");
            System.out.println(String.format("Agora você tem %.2f KPoints", saldo));
            System.out.println("--------------------------------------------");
            
        } else if (cont <= 6) {
            
            saldo++;
            System.out.println("Você é um pouco sortudo - Você ganhou 1 KPoints");
            System.out.println(String.format("Agora você tem %.2f KPoints", saldo));
            System.out.println("--------------------------------------------");
            
        } else{
            
            System.out.println("É melhor você parar de apostar e ir estudar! "
                    + "- Você ganhou 0 KPoints");
            System.out.println(String.format("Você continuou com %.2f KPoints", saldo));
            System.out.println("---------------------------------------------");
        }
        
                

                
              
        break;
            case 0:
                
                System.out.println("Até logo");
                
                acesso = false;
                break;
               
            default:
                
                System.out.println("Opção inválida, tente novamente");
        }
        }
    }
    }

